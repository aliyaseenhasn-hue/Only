# Workspace

## Overview

pnpm workspace monorepo using TypeScript. Each package manages its own dependencies.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm
- **TypeScript version**: 5.9
- **API framework**: Express 5
- **Database**: PostgreSQL + Drizzle ORM
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle)
- **Auth**: Clerk (Replit-managed, activates on production live keys)

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally

See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details.

## Applications

### Social Radar (`artifacts/social-radar`)
- **Preview path**: `/`
- **Purpose**: Location-based social discovery app in Arabic (RTL)
- **Theme**: Dark space aesthetic, electric cyan (#00d4e8 / hsl(187 100% 42%)), Tajawal font
- **Features**:
  - **Landing page**: Arabic landing with animated radar icon, sign-in/sign-up CTA
  - **Clerk auth**: Google login + email via Clerk (activates automatically in production with live keys). Dev uses a bypass fallback since `pk_test_*` keys don't allow custom proxy hosts.
  - **Profile setup**: Avatar picker (DiceBear), name, bio, interests
  - **Profile edit**: Full edit form (same fields), accessible via NavBar dropdown
  - **Animated radar**: Canvas-based radar sweep showing nearby users as clickable avatar dots
  - **Radar pause/resume**: Toggle button dims the sweep and stops location polling
  - **Browser push notifications**: `Notification` API fires when a new nearby person appears; falls back to in-app toast
  - **Discover page**: Grid of all users with distance
  - **Profile view**: Per-user profile page
  - **NavBar**: Logo, nav links, user avatar dropdown with sign-out (sign-out hidden in dev mode)
  - **Real-time location**: Browser geolocation API; defaults to Riyadh if denied
- **Current user**: Stored in localStorage under `social-radar-user` (id, name, bio, avatarUrl, interests[])
- **Demo data**: 8 seeded Arabic-named users in Riyadh area

### API Server (`artifacts/api-server`)
- **Preview path**: `/api`
- **Routes**: `/api/users`, `/api/radar/nearby`, `/api/radar/stats`
- **Clerk proxy**: `/api/__clerk` proxied to `https://frontend-api.clerk.dev` (active in dev + prod). The `Clerk-Proxy-Url` header uses `REPLIT_DOMAINS` so redirects resolve to the public domain.
- **Clerk middleware**: `clerkMiddleware` from `@clerk/express` validates session tokens on all requests (routes not yet individually protected — user data stored in localStorage)

## Architecture Notes

- `lib/api-spec/openapi.yaml` — single source of truth for API contract
- `lib/db/src/schema/users.ts` — users table with lat/lng for geolocation
- `artifacts/api-server/src/routes/users.ts` — user CRUD routes
- `artifacts/api-server/src/routes/radar.ts` — nearby search + stats using Haversine formula
- `artifacts/social-radar/src/lib/clerkContext.tsx` — `ClerkContextAvailableProvider` (inside ClerkProvider, exposes `signOut`/`clerkUser`) and `ClerkContextUnavailableProvider` (dev fallback, no-ops). NavBar reads from this context to avoid calling Clerk hooks outside ClerkProvider.
- Codegen script auto-fixes `lib/api-zod/src/index.ts` after orval runs (avoids duplicate export conflict)
- `@layer theme, base, clerk, components, utilities` declared before Tailwind import so Clerk themes layer is ordered correctly

import { Router, type IRouter } from "express";
import healthRouter from "./health";
import usersRouter from "./users";
import radarRouter from "./radar";
import aiRouter from "./ai";
import otpRouter from "./otp";

const router: IRouter = Router();

router.use(healthRouter);
router.use(usersRouter);
router.use(radarRouter);
router.use(aiRouter);
router.use(otpRouter);

export default router;

import { Router, type IRouter } from "express";
import { SendOtpBody, VerifyOtpBody } from "@workspace/api-zod";

const router: IRouter = Router();

interface OtpEntry {
  code: string;
  expiresAt: number;
  attempts: number;
}

const otpStore = new Map<string, OtpEntry>();

const OTP_TTL_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 5;

function generateCode(): string {
  return String(Math.floor(1000 + Math.random() * 9000));
}

function cleanupExpired() {
  const now = Date.now();
  for (const [key, entry] of otpStore) {
    if (entry.expiresAt < now) otpStore.delete(key);
  }
}

router.post("/auth/send-otp", (req, res): void => {
  const parsed = SendOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "رقم الهاتف غير صحيح" });
    return;
  }

  cleanupExpired();

  const { phone } = parsed.data;
  const code = generateCode();

  otpStore.set(phone, {
    code,
    expiresAt: Date.now() + OTP_TTL_MS,
    attempts: 0,
  });

  req.log.info({ phone: phone.slice(0, -4) + "****" }, "OTP sent");

  const isDev = process.env.NODE_ENV !== "production";

  res.json({
    success: true,
    expiresIn: 300,
    ...(isDev && { devCode: code }),
  });
});

router.post("/auth/verify-otp", (req, res): void => {
  const parsed = VerifyOtpBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "بيانات غير صحيحة" });
    return;
  }

  const { phone, code } = parsed.data;
  const entry = otpStore.get(phone);

  if (!entry) {
    res.status(400).json({ error: "لم يتم إرسال رمز لهذا الرقم، أو انتهت صلاحيته" });
    return;
  }

  if (Date.now() > entry.expiresAt) {
    otpStore.delete(phone);
    res.status(400).json({ error: "انتهت صلاحية الرمز، اطلب رمزاً جديداً" });
    return;
  }

  entry.attempts += 1;

  if (entry.attempts > MAX_ATTEMPTS) {
    otpStore.delete(phone);
    res.status(429).json({ error: "تجاوزت عدد المحاولات المسموح بها، اطلب رمزاً جديداً" });
    return;
  }

  if (entry.code !== code) {
    res.status(400).json({ error: `رمز التحقق غير صحيح (${MAX_ATTEMPTS - entry.attempts} محاولات متبقية)` });
    return;
  }

  otpStore.delete(phone);
  res.json({ success: true });
});

export default router;

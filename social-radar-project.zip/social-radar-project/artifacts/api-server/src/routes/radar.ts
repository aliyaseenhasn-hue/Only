import { Router, type IRouter } from "express";
import { and, isNotNull, ne } from "drizzle-orm";
import { db, usersTable } from "@workspace/db";
import {
  GetNearbyUsersQueryParams,
  GetNearbyUsersResponse,
  GetRadarStatsQueryParams,
  GetRadarStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function serializeUser(u: typeof usersTable.$inferSelect) {
  return {
    ...u,
    lastSeen: u.lastSeen?.toISOString() ?? null,
    createdAt: u.createdAt?.toISOString() ?? new Date().toISOString(),
  };
}

router.get("/radar/nearby", async (req, res): Promise<void> => {
  const parsed = GetNearbyUsersQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { lat, lng, radius = 5, excludeUserId } = parsed.data;

  const conditions = [isNotNull(usersTable.lat), isNotNull(usersTable.lng)];
  if (excludeUserId) {
    conditions.push(ne(usersTable.id, excludeUserId));
  }

  const users = await db
    .select()
    .from(usersTable)
    .where(and(...conditions));

  const nearby = users
    .map((u) => ({
      ...serializeUser(u),
      distanceKm: haversineKm(lat, lng, u.lat!, u.lng!),
    }))
    .filter((u) => u.distanceKm <= radius)
    .sort((a, b) => a.distanceKm - b.distanceKm);

  res.json(GetNearbyUsersResponse.parse(nearby));
});

router.get("/radar/stats", async (req, res): Promise<void> => {
  const parsed = GetRadarStatsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { lat, lng } = parsed.data;
  const radius = 10;

  const users = await db
    .select()
    .from(usersTable)
    .where(and(isNotNull(usersTable.lat), isNotNull(usersTable.lng)));

  const nearbyWithDist = users
    .map((u) => ({
      distanceKm: haversineKm(lat, lng, u.lat!, u.lng!),
      isOnline: u.isOnline,
    }))
    .filter((u) => u.distanceKm <= radius);

  const onlineNearby = nearbyWithDist.filter((u) => u.isOnline).length;
  const distances = nearbyWithDist.map((u) => u.distanceKm);
  const closestDistanceKm = distances.length > 0 ? Math.min(...distances) : null;
  const averageDistanceKm =
    distances.length > 0 ? distances.reduce((a, b) => a + b, 0) / distances.length : null;

  res.json(
    GetRadarStatsResponse.parse({
      totalNearby: nearbyWithDist.length,
      onlineNearby,
      closestDistanceKm,
      averageDistanceKm,
    })
  );
});

export default router;

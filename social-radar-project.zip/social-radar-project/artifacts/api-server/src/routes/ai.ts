import { Router, type IRouter } from "express";
import { GoogleGenAI } from "@google/genai";
import { SuggestConversationBody, SuggestConversationResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY ?? "",
  httpOptions: { apiVersion: "v1" },
});

router.post("/ai/suggest-conversation", async (req, res): Promise<void> => {
  const parsed = SuggestConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { myName, myInterests, theirName, theirInterests } = parsed.data;
  const common = myInterests.filter((i) => theirInterests.includes(i));

  const prompt = `أنت مساعد اجتماعي ذكي. اقترح 3 جمل افتتاحية قصيرة وودية باللغة العربية لبدء محادثة مع شخص جديد.

معلوماتي:
- اسمي: ${myName}
- اهتماماتي: ${myInterests.join("، ")}

معلومات الشخص الآخر:
- اسمه: ${theirName}
- اهتماماته: ${theirInterests.join("، ")}

الاهتمامات المشتركة: ${common.length > 0 ? common.join("، ") : "لا توجد اهتمامات مشتركة واضحة"}

اقترح 3 جمل افتتاحية فقط، كل جملة في سطر مستقل، بدون ترقيم أو تنسيق إضافي. الجمل يجب أن تكون طبيعية وغير رسمية ومناسبة لتطبيق اجتماعي.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-lite",
      contents: prompt,
    });

    const text = (response.text ?? "").trim();
    const suggestions = text
      .split("\n")
      .map((s: string) => s.trim())
      .filter((s: string) => s.length > 0)
      .slice(0, 3);

    res.json(SuggestConversationResponse.parse({ suggestions }));
  } catch (err: unknown) {
    const errMsg = err instanceof Error ? err.message : String(err);
    req.log.error({ err, errMsg }, "Gemini API error");
    res.status(500).json({ error: "تعذّر توليد الاقتراحات، حاول مرة أخرى" });
  }
});

export default router;

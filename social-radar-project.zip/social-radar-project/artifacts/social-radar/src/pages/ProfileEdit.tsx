import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useUpdateUser } from "@workspace/api-client-react";
import { getCurrentUser, setCurrentUser } from "@/lib/currentUser";
import NavBar from "@/components/NavBar";
import { useToast } from "@/hooks/use-toast";

const INTERESTS = [
  "تصميم", "برمجة", "تقنية", "فن", "موسيقى", "رياضة", "قراءة", "كتابة",
  "سفر", "طبيعة", "تصوير", "طبخ", "مسرح", "أعمال", "استثمار", "تعليم",
  "لياقة", "صحة", "ثقافة", "تاريخ", "ألعاب", "مطاعم"
];

const AVATAR_SEEDS = [
  "sara", "ahmed", "noura", "faisal", "reem", "omar", "lamia", "khalid",
  "mona", "tariq", "hind", "bader"
];

const BG_COLORS = [
  "b6e3f4", "c0aede", "ffdfbf", "d1f7c4", "ffd3e8", "e8d5b7", "c9f0ff", "ffe4b5",
  "f0d9ff", "d4f0e8", "ffecd2", "e8f4fd"
];

function getAvatarIndex(avatarUrl?: string): number {
  if (!avatarUrl) return 0;
  for (let i = 0; i < AVATAR_SEEDS.length; i++) {
    if (avatarUrl.includes(`seed=${AVATAR_SEEDS[i]}`)) return i;
  }
  return 0;
}

export default function ProfileEdit() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const currentUser = getCurrentUser();

  const [name, setName] = useState(currentUser?.name || "");
  const [bio, setBio] = useState(currentUser?.bio || "");
  const [instagram, setInstagram] = useState(currentUser?.instagramHandle || "");
  const [selectedInterests, setSelectedInterests] = useState<string[]>(currentUser?.interests || []);
  const [avatarIndex, setAvatarIndex] = useState(getAvatarIndex(currentUser?.avatarUrl));
  const [error, setError] = useState("");

  const updateUser = useUpdateUser();

  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${AVATAR_SEEDS[avatarIndex]}&backgroundColor=${BG_COLORS[avatarIndex]}`;

  function toggleInterest(interest: string) {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  }

  async function handleSave(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      setError("يرجى إدخال اسمك");
      return;
    }
    if (!currentUser) {
      setError("لم يتم العثور على ملفك الشخصي");
      return;
    }

    try {
      await updateUser.mutateAsync({
        userId: currentUser.id,
        data: {
          name: name.trim(),
          bio: bio.trim(),
          avatarUrl,
          interests: selectedInterests,
          instagramHandle: instagram.trim() || undefined,
        },
      });

      setCurrentUser({
        ...currentUser,
        name: name.trim(),
        bio: bio.trim(),
        avatarUrl,
        interests: selectedInterests,
        instagramHandle: instagram.trim() || undefined,
      });

      toast({ title: "تم الحفظ", description: "تم تحديث ملفك الشخصي بنجاح" });
      navigate(`/profile/${currentUser.id}`);
    } catch {
      setError("حدث خطأ، يرجى المحاولة مجدداً");
    }
  }

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-background grid-bg" dir="rtl">
        <NavBar />
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <p className="text-muted-foreground">لم يتم إنشاء ملفك الشخصي بعد</p>
          <button
            onClick={() => navigate("/profile/setup")}
            className="px-4 py-2 rounded-lg text-sm font-bold"
            style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
          >
            إنشاء الملف الشخصي
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background grid-bg" dir="rtl">
      <NavBar />

      <div className="max-w-lg mx-auto px-4 py-6">
        <div className="mb-6">
          <h1 className="text-xl font-bold" style={{ color: "hsl(187 100% 42%)" }}>تعديل الملف الشخصي</h1>
          <p className="text-muted-foreground text-sm mt-1">حدّث معلوماتك وصورتك الشخصية</p>
        </div>

        <form onSubmit={handleSave} className="space-y-5">
          {/* Avatar picker */}
          <div className="flex flex-col items-center gap-3 p-4 rounded-xl border"
            style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(210 25% 18%)" }}>
            <img
              src={avatarUrl}
              alt="الصورة الرمزية"
              className="w-24 h-24 rounded-full border-2"
              style={{ borderColor: "hsl(187 100% 42%)" }}
            />
            <p className="text-xs text-muted-foreground">اختر صورة رمزية</p>
            <div className="flex gap-2 flex-wrap justify-center">
              {AVATAR_SEEDS.map((seed, i) => (
                <button
                  key={seed}
                  type="button"
                  onClick={() => setAvatarIndex(i)}
                  className="w-9 h-9 rounded-full overflow-hidden border-2 transition-all"
                  style={{
                    borderColor: avatarIndex === i ? "hsl(187 100% 42%)" : "transparent",
                    opacity: avatarIndex === i ? 1 : 0.55,
                    transform: avatarIndex === i ? "scale(1.1)" : "scale(1)",
                  }}
                >
                  <img
                    src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&backgroundColor=${BG_COLORS[i]}`}
                    alt={seed}
                    className="w-full h-full"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              الاسم <span style={{ color: "hsl(187 100% 42%)" }}>*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="أدخل اسمك"
              className="w-full px-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all"
              style={{ borderColor: "hsl(210 25% 20%)", "--tw-ring-color": "hsl(187 100% 42% / 0.5)" } as React.CSSProperties}
            />
          </div>

          {/* Bio */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">نبذة عنك</label>
            <textarea
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="اكتب شيئاً مختصراً عن نفسك..."
              rows={3}
              className="w-full px-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all resize-none"
              style={{ borderColor: "hsl(210 25% 20%)", "--tw-ring-color": "hsl(187 100% 42% / 0.5)" } as React.CSSProperties}
            />
          </div>

          {/* Instagram */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              حساب الإنستقرام
            </label>
            <div className="relative">
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm select-none">@</span>
              <input
                type="text"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value.replace(/^@/, ""))}
                placeholder="username"
                dir="ltr"
                className="w-full pr-8 pl-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all"
                style={{ borderColor: "hsl(210 25% 20%)", "--tw-ring-color": "hsl(187 100% 42% / 0.5)" } as React.CSSProperties}
              />
            </div>
          </div>

          {/* Interests */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              الاهتمامات ({selectedInterests.length} مختار)
            </label>
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map((interest) => {
                const selected = selectedInterests.includes(interest);
                return (
                  <button
                    key={interest}
                    type="button"
                    onClick={() => toggleInterest(interest)}
                    className="px-3 py-1.5 rounded-full text-sm font-medium transition-all border"
                    style={{
                      backgroundColor: selected ? "hsl(187 100% 42% / 0.15)" : "hsl(220 28% 9%)",
                      borderColor: selected ? "hsl(187 100% 42%)" : "hsl(210 25% 20%)",
                      color: selected ? "hsl(187 100% 42%)" : "hsl(210 20% 55%)",
                    }}
                  >
                    {interest}
                  </button>
                );
              })}
            </div>
          </div>

          {error && <p className="text-sm text-red-400 text-center">{error}</p>}

          {/* Actions */}
          <div className="flex gap-3 pt-2">
            <button
              type="submit"
              disabled={updateUser.isPending}
              className="flex-1 py-3 rounded-xl font-bold text-sm transition-all glow-cyan"
              style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)", opacity: updateUser.isPending ? 0.7 : 1 }}
            >
              {updateUser.isPending ? "جاري الحفظ..." : "حفظ التغييرات"}
            </button>
            <button
              type="button"
              onClick={() => navigate(-1 as never)}
              className="flex-1 py-3 rounded-xl font-bold text-sm border transition-all"
              style={{ borderColor: "hsl(210 25% 20%)", color: "hsl(210 20% 55%)" }}
            >
              إلغاء
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

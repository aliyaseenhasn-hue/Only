import { useLocation } from "wouter";

export default function NotFound() {
  const [, navigate] = useLocation();
  return (
    <div className="min-h-screen bg-background flex items-center justify-center" dir="rtl">
      <div className="text-center space-y-4">
        <div className="text-6xl font-black glow-text-cyan" style={{ color: "hsl(187 100% 42%)" }}>404</div>
        <p className="text-muted-foreground">الصفحة غير موجودة</p>
        <button
          onClick={() => navigate("/")}
          className="px-6 py-2.5 rounded-lg font-medium text-sm"
          style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
        >
          العودة للرادار
        </button>
      </div>
    </div>
  );
}

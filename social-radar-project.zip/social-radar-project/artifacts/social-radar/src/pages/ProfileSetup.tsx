import { useState } from "react";
import { useLocation } from "wouter";
import { useCreateUser } from "@workspace/api-client-react";
import { setCurrentUser } from "@/lib/currentUser";

const INTERESTS = [
  "تصميم", "برمجة", "تقنية", "فن", "موسيقى", "رياضة", "قراءة", "كتابة",
  "سفر", "طبيعة", "تصوير", "طبخ", "مسرح", "أعمال", "استثمار", "تعليم",
  "لياقة", "صحة", "ثقافة", "تاريخ", "ألعاب", "مطاعم"
];

const AVATAR_SEEDS = [
  "sara", "ahmed", "noura", "faisal", "reem", "omar", "lamia", "khalid",
  "mona", "tariq", "hind", "bader"
];

const BG_COLORS = [
  "b6e3f4", "c0aede", "ffdfbf", "d1f7c4", "ffd3e8", "e8d5b7", "c9f0ff", "ffe4b5",
  "f0d9ff", "d4f0e8", "ffecd2", "e8f4fd"
];

export default function ProfileSetup() {
  const [, navigate] = useLocation();
  const [name, setName] = useState("");
  const [bio, setBio] = useState("");
  const [instagram, setInstagram] = useState("");
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);
  const [avatarIndex, setAvatarIndex] = useState(0);
  const [error, setError] = useState("");

  const createUser = useCreateUser();

  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${AVATAR_SEEDS[avatarIndex]}&backgroundColor=${BG_COLORS[avatarIndex]}`;

  function toggleInterest(interest: string) {
    setSelectedInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) { setError("يرجى إدخال اسمك"); return; }
    try {
      const user = await createUser.mutateAsync({
        data: { name: name.trim(), bio: bio.trim(), avatarUrl, interests: selectedInterests, instagramHandle: instagram.trim() || undefined },
      });
      setCurrentUser({ id: user.id, name: user.name, bio: user.bio ?? undefined, avatarUrl: user.avatarUrl ?? undefined, interests: selectedInterests, instagramHandle: instagram.trim() || undefined });
      navigate("/radar");
    } catch {
      setError("حدث خطأ، يرجى المحاولة مجدداً");
    }
  }

  return (
    <div className="min-h-screen bg-background grid-bg flex items-center justify-center p-4" dir="rtl">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 border border-primary/30 mb-4 glow-cyan">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" style={{ color: "hsl(187 100% 42%)" }}>
              <circle cx="12" cy="12" r="3" fill="currentColor" />
              <circle cx="12" cy="12" r="7" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
              <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="1" opacity="0.3" />
            </svg>
          </div>
          <h1 className="text-2xl font-bold glow-text-cyan" style={{ color: "hsl(187 100% 42%)" }}>أكمل ملفك الشخصي</h1>
          <p className="text-muted-foreground mt-1 text-sm">أضف بعض المعلومات لتبدأ الاستكشاف</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Avatar picker */}
          <div className="flex flex-col items-center gap-3">
            <img src={avatarUrl} alt="الصورة الرمزية" className="w-24 h-24 rounded-full border-2 glow-cyan" style={{ borderColor: "hsl(187 100% 42%)" }} />
            <div className="flex gap-2 flex-wrap justify-center">
              {AVATAR_SEEDS.map((seed, i) => (
                <button key={seed} type="button" onClick={() => setAvatarIndex(i)}
                  className="w-8 h-8 rounded-full overflow-hidden border-2 transition-all"
                  style={{ borderColor: avatarIndex === i ? "hsl(187 100% 42%)" : "transparent", opacity: avatarIndex === i ? 1 : 0.5 }}>
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&backgroundColor=${BG_COLORS[i]}`} alt={seed} className="w-full h-full" />
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">الاسم <span style={{ color: "hsl(187 100% 42%)" }}>*</span></label>
            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="أدخل اسمك"
              className="w-full px-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all"
              style={{ borderColor: "hsl(210 25% 20%)" }} />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">نبذة عنك</label>
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} placeholder="اكتب شيئاً مختصراً عن نفسك..." rows={3}
              className="w-full px-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all resize-none"
              style={{ borderColor: "hsl(210 25% 20%)" }} />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">
              حساب الإنستقرام
            </label>
            <div className="relative">
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-sm select-none">@</span>
              <input
                type="text"
                value={instagram}
                onChange={(e) => setInstagram(e.target.value.replace(/^@/, ""))}
                placeholder="username"
                dir="ltr"
                className="w-full pr-8 pl-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 transition-all text-left"
                style={{ borderColor: "hsl(210 25% 20%)" }}
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">اهتماماتك ({selectedInterests.length} مختار)</label>
            <div className="flex flex-wrap gap-2">
              {INTERESTS.map((interest) => {
                const selected = selectedInterests.includes(interest);
                return (
                  <button key={interest} type="button" onClick={() => toggleInterest(interest)}
                    className="px-3 py-1.5 rounded-full text-sm font-medium transition-all border"
                    style={{ backgroundColor: selected ? "hsl(187 100% 42% / 0.15)" : "hsl(220 28% 9%)", borderColor: selected ? "hsl(187 100% 42%)" : "hsl(210 25% 20%)", color: selected ? "hsl(187 100% 42%)" : "hsl(210 20% 55%)" }}>
                    {interest}
                  </button>
                );
              })}
            </div>
          </div>

          {error && <p className="text-sm text-red-400 text-center">{error}</p>}

          <button type="submit" disabled={createUser.isPending}
            className="w-full py-3 rounded-lg font-bold text-base transition-all glow-cyan"
            style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)", opacity: createUser.isPending ? 0.7 : 1 }}>
            {createUser.isPending ? "جاري الإنشاء..." : "ابدأ الاستكشاف"}
          </button>
        </form>
      </div>
    </div>
  );
}

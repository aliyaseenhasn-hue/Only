import { useEffect, useRef, useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useGetNearbyUsers, useGetRadarStats, useUpdateLocation, useSuggestConversation } from "@workspace/api-client-react";
import { getCurrentUser } from "@/lib/currentUser";
import NavBar from "@/components/NavBar";
import UserCard from "@/components/UserCard";
import { useToast } from "@/hooks/use-toast";

const DEFAULT_LAT = 24.7136;
const DEFAULT_LNG = 46.6753;

interface RadarDot {
  id: string;
  name: string;
  avatarUrl?: string;
  isOnline: boolean;
  x: number;
  y: number;
  distanceKm: number;
  commonInterests: string[];
}

const SIZE = 280;
const CENTER = SIZE / 2;

export default function RadarPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const currentUser = getCurrentUser();

  const [lat, setLat] = useState(DEFAULT_LAT);
  const [lng, setLng] = useState(DEFAULT_LNG);
  const [radius, setRadius] = useState(5);
  const [selectedDot, setSelectedDot] = useState<string | null>(null);
  const [isPaused, setIsPaused] = useState(false);
  const [aiSuggestions, setAiSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const sweepAngle = useRef(0);
  const animRef = useRef<number>(0);
  const prevNearbyIds = useRef<Set<string>>(new Set());
  const notifPermission = useRef<NotificationPermission>("default");

  const updateLocation = useUpdateLocation();
  const suggestConversation = useSuggestConversation();

  // Request notification permission
  useEffect(() => {
    if ("Notification" in window) {
      Notification.requestPermission().then((p) => {
        notifPermission.current = p;
      });
    }
  }, []);

  // Get geolocation
  useEffect(() => {
    if (!currentUser) {
      navigate("/profile/setup");
      return;
    }
    navigator.geolocation?.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        setLat(latitude);
        setLng(longitude);
        updateLocation.mutate({ userId: currentUser.id, data: { lat: latitude, lng: longitude } });
      },
      () => {
        updateLocation.mutate({ userId: currentUser.id, data: { lat: DEFAULT_LAT, lng: DEFAULT_LNG } });
      }
    );
  }, []);

  const { data: nearbyUsers = [] } = useGetNearbyUsers(
    { lat, lng, radius, excludeUserId: currentUser?.id },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    { query: { enabled: !isPaused, refetchInterval: isPaused ? false : 15000 } as any }
  );

  const { data: stats } = useGetRadarStats(
    { lat, lng },
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    { query: { enabled: !isPaused, refetchInterval: isPaused ? false : 15000 } as any }
  );

  // Nearby notification logic
  useEffect(() => {
    if (isPaused || nearbyUsers.length === 0) return;

    const currentIds = new Set(nearbyUsers.map((u) => u.id));
    const newArrivals = nearbyUsers.filter((u) => !prevNearbyIds.current.has(u.id));

    if (newArrivals.length > 0 && prevNearbyIds.current.size > 0) {
      newArrivals.forEach((u) => {
        // In-app toast notification
        toast({
          title: "شخص قريب منك",
          description: `${u.name} على بعد ${u.distanceKm.toFixed(1)} كم منك`,
        });

        // Browser notification
        if (notifPermission.current === "granted") {
          new Notification("رادار اجتماعي — شخص قريب منك", {
            body: `${u.name} على بعد ${u.distanceKm.toFixed(1)} كم`,
            icon: "/logo.svg",
          });
        }
      });
    }

    prevNearbyIds.current = currentIds;
  }, [nearbyUsers, isPaused]);

  const myInterests = new Set(currentUser?.interests ?? []);

  // Map users to radar dots
  const dots: RadarDot[] = nearbyUsers
    .filter((u) => u.lat != null && u.lng != null)
    .map((u) => {
      const dLat = (u.lat! - lat) * 111;
      const dLng = (u.lng! - lng) * 111 * Math.cos((lat * Math.PI) / 180);
      const angle = Math.atan2(dLng, dLat);
      const dist = Math.min(u.distanceKm / radius, 0.95);
      const r = dist * (CENTER - 20);
      const commonInterests = (u.interests ?? []).filter((i) => myInterests.has(i));
      return {
        id: u.id,
        name: u.name,
        avatarUrl: u.avatarUrl ?? undefined,
        isOnline: u.isOnline,
        x: CENTER + r * Math.sin(angle),
        y: CENTER - r * Math.cos(angle),
        distanceKm: u.distanceKm,
        commonInterests,
      };
    });

  // Animated radar canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    const CYAN = "rgba(0,220,255,";
    const PAUSED_COLOR = "rgba(150,150,200,";

    function draw() {
      ctx.clearRect(0, 0, SIZE, SIZE);
      const C = isPaused ? PAUSED_COLOR : CYAN;

      // Background
      ctx.beginPath();
      ctx.arc(CENTER, CENTER, CENTER - 2, 0, Math.PI * 2);
      ctx.fillStyle = isPaused ? "hsl(220,15%,6%)" : "hsl(220,30%,6%)";
      ctx.fill();

      // Rings
      [0.25, 0.5, 0.75, 1].forEach((ratio) => {
        ctx.beginPath();
        ctx.arc(CENTER, CENTER, ratio * (CENTER - 2), 0, Math.PI * 2);
        ctx.strokeStyle = `${C}0.12)`;
        ctx.lineWidth = 1;
        ctx.stroke();
      });

      // Cross lines
      ctx.beginPath();
      ctx.moveTo(CENTER, 2); ctx.lineTo(CENTER, SIZE - 2);
      ctx.moveTo(2, CENTER); ctx.lineTo(SIZE - 2, CENTER);
      ctx.strokeStyle = `${C}0.08)`;
      ctx.lineWidth = 1;
      ctx.stroke();

      if (!isPaused) {
        sweepAngle.current = (sweepAngle.current + 0.015) % (Math.PI * 2);
      }
      const angle = sweepAngle.current;

      ctx.save();
      ctx.translate(CENTER, CENTER);
      ctx.rotate(angle);

      const sweepGrad = ctx.createLinearGradient(0, 0, CENTER, 0);
      sweepGrad.addColorStop(0, `${C}0)`);
      sweepGrad.addColorStop(0.6, `${C}${isPaused ? "0.04" : "0.08"})`);
      sweepGrad.addColorStop(1, `${C}${isPaused ? "0.1" : "0.25"})`);

      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.arc(0, 0, CENTER - 2, -0.3, 0.3);
      ctx.closePath();
      ctx.fillStyle = sweepGrad;
      ctx.fill();

      // Sweep line
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(CENTER - 2, 0);
      ctx.strokeStyle = `${C}${isPaused ? "0.3" : "0.8"})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.restore();

      // Outer border
      ctx.beginPath();
      ctx.arc(CENTER, CENTER, CENTER - 2, 0, Math.PI * 2);
      ctx.strokeStyle = `${C}0.4)`;
      ctx.lineWidth = 2;
      ctx.stroke();

      // Center dot
      ctx.beginPath();
      ctx.arc(CENTER, CENTER, 5, 0, Math.PI * 2);
      ctx.fillStyle = `${C}1)`;
      ctx.fill();

      // Paused text
      if (isPaused) {
        ctx.font = "bold 13px Tajawal, sans-serif";
        ctx.fillStyle = "rgba(150,150,200,0.7)";
        ctx.textAlign = "center";
        ctx.fillText("متوقف", CENTER, CENTER + 20);
      }

      animRef.current = requestAnimationFrame(draw);
    }

    draw();
    return () => cancelAnimationFrame(animRef.current);
  }, [isPaused]);

  const selectedUser = nearbyUsers.find((u) => u.id === selectedDot) ?? null;

  return (
    <div className="min-h-screen bg-background grid-bg" dir="rtl">
      <NavBar />

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-6">
        {/* Stats bar */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "قريب منك", value: stats?.totalNearby ?? nearbyUsers.length },
            { label: "متصل الآن", value: stats?.onlineNearby ?? nearbyUsers.filter((u) => u.isOnline).length },
            { label: "أقرب (كم)", value: stats?.closestDistanceKm?.toFixed(1) ?? "—" },
          ].map((s) => (
            <div
              key={s.label}
              className="rounded-xl border p-3 text-center"
              style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(210 25% 18%)" }}
            >
              <div className="text-2xl font-bold glow-text-cyan" style={{ color: isPaused ? "hsl(210 20% 55%)" : "hsl(187 100% 42%)" }}>
                {isPaused ? "—" : s.value}
              </div>
              <div className="text-xs text-muted-foreground mt-0.5">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Radar + pause button */}
        <div className="flex flex-col items-center gap-4">
          <div className="relative" style={{ width: SIZE, height: SIZE }}>
            <canvas
              ref={canvasRef}
              width={SIZE}
              height={SIZE}
              className="rounded-full"
              style={{
                display: "block",
                boxShadow: isPaused
                  ? "0 0 20px rgba(150,150,200,0.15)"
                  : "0 0 20px rgba(0,220,255,0.3), 0 0 40px rgba(0,220,255,0.1)",
              }}
            />
            {/* User dots */}
            {!isPaused && dots.map((dot, i) => {
              const hasMatch = dot.commonInterests.length > 0;
              const dotBorderColor = hasMatch
                ? "hsl(142 71% 45%)"
                : dot.isOnline
                ? "hsl(187 100% 60%)"
                : "hsl(187 100% 42%)";
              const dotShadow = hasMatch
                ? "0 0 10px rgba(0,200,120,0.8), 0 0 4px rgba(0,200,120,0.4)"
                : dot.isOnline
                ? "0 0 8px rgba(0,220,255,0.6)"
                : "0 0 8px rgba(0,220,255,0.3)";
              return (
                <button
                  key={dot.id}
                  onClick={() => {
                    setSelectedDot(dot.id === selectedDot ? null : dot.id);
                    setAiSuggestions([]);
                    setShowSuggestions(false);
                  }}
                  className="absolute dot-appear"
                  style={{ left: dot.x - 12, top: dot.y - 12, animationDelay: `${i * 0.1}s` }}
                  title={dot.name}
                >
                  {/* Match ring */}
                  {hasMatch && (
                    <div
                      className="absolute inset-0 rounded-full radar-pulse"
                      style={{ borderWidth: 1, borderStyle: "solid", borderColor: "hsl(142 71% 45% / 0.6)" }}
                    />
                  )}
                  <div
                    className="w-6 h-6 rounded-full border-2 overflow-hidden transition-transform hover:scale-125 relative"
                    style={{
                      borderColor: dotBorderColor,
                      boxShadow: dotShadow,
                      transform: dot.id === selectedDot ? "scale(1.4)" : "scale(1)",
                    }}
                  >
                    {dot.avatarUrl ? (
                      <img src={dot.avatarUrl} alt={dot.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-xs font-bold"
                        style={{ backgroundColor: hasMatch ? "hsl(142 71% 25%)" : "hsl(187 100% 42%)", color: hasMatch ? "hsl(142 71% 85%)" : "hsl(220 30% 5%)" }}>
                        {dot.name[0]}
                      </div>
                    )}
                  </div>
                </button>
              );
            })}

            {!isPaused && dots.length === 0 && nearbyUsers.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <p className="text-xs text-muted-foreground">لا أحد في النطاق</p>
              </div>
            )}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4 w-full max-w-xs">
            {/* Pause button */}
            <button
              onClick={() => setIsPaused((p) => !p)}
              className="flex items-center gap-1.5 px-4 py-2 rounded-lg border text-sm font-medium transition-all flex-shrink-0"
              style={{
                backgroundColor: isPaused ? "hsl(187 100% 42% / 0.15)" : "hsl(220 28% 9%)",
                borderColor: isPaused ? "hsl(187 100% 42%)" : "hsl(210 25% 20%)",
                color: isPaused ? "hsl(187 100% 42%)" : "hsl(210 20% 55%)",
              }}
            >
              {isPaused ? (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5v14l11-7z" /></svg>
                  تشغيل
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z" /></svg>
                  إيقاف
                </>
              )}
            </button>

            {/* Radius slider */}
            <div className="flex-1">
              <div className="flex justify-between text-xs text-muted-foreground mb-1">
                <span>النطاق</span>
                <span style={{ color: "hsl(187 100% 42%)" }}>{radius} كم</span>
              </div>
              <input
                type="range"
                min={1} max={20} value={radius}
                onChange={(e) => setRadius(Number(e.target.value))}
                disabled={isPaused}
                className="w-full h-1.5 rounded-full appearance-none cursor-pointer"
                style={{
                  background: `linear-gradient(to left, hsl(187 100% 42%) ${(radius / 20) * 100}%, hsl(210 25% 20%) ${(radius / 20) * 100}%)`,
                  accentColor: "hsl(187 100% 42%)",
                  opacity: isPaused ? 0.4 : 1,
                }}
              />
            </div>
          </div>

          {/* Paused notice */}
          {isPaused && (
            <div className="text-xs text-muted-foreground border rounded-lg px-3 py-1.5 fade-in-up"
              style={{ borderColor: "hsl(210 25% 18%)" }}>
              الرادار متوقف — لن تصلك تنبيهات
            </div>
          )}
        </div>

        {/* Selected user popup */}
        {selectedUser && (
          <div
            className="rounded-xl border p-4 fade-in-up space-y-3"
            style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(187 100% 42% / 0.4)" }}
          >
            <UserCard user={selectedUser} showDistance />

            {/* Instagram link */}
            {selectedUser.instagramHandle && (
              <a
                href={`https://instagram.com/${selectedUser.instagramHandle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
                style={{
                  background: "linear-gradient(135deg, hsl(330 80% 20% / 0.5) 0%, hsl(280 60% 20% / 0.4) 50%, hsl(40 90% 20% / 0.4) 100%)",
                  border: "1px solid hsl(330 80% 45% / 0.5)",
                  color: "hsl(330 80% 80%)",
                  textDecoration: "none",
                }}
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                  <defs>
                    <linearGradient id="ig-popup-grad" x1="0" y1="24" x2="24" y2="0">
                      <stop offset="0%" stopColor="#f09433" />
                      <stop offset="40%" stopColor="#dc2743" />
                      <stop offset="100%" stopColor="#bc1888" />
                    </linearGradient>
                  </defs>
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="url(#ig-popup-grad)" strokeWidth="2" fill="none" />
                  <circle cx="12" cy="12" r="4" stroke="url(#ig-popup-grad)" strokeWidth="2" fill="none" />
                  <circle cx="17.5" cy="6.5" r="1.2" fill="url(#ig-popup-grad)" />
                </svg>
                <span>@{selectedUser.instagramHandle}</span>
                <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" style={{ opacity: 0.6 }}>
                  <path d="M7 17L17 7M17 7H7M17 7V17" />
                </svg>
              </a>
            )}

            {/* AI suggestions button */}
            <button
              onClick={async () => {
                if (!currentUser) return;
                setShowSuggestions(true);
                setAiSuggestions([]);
                try {
                  const result = await suggestConversation.mutateAsync({
                    data: {
                      myName: currentUser.name,
                      myInterests: currentUser.interests,
                      theirName: selectedUser.name,
                      theirInterests: selectedUser.interests ?? [],
                    },
                  });
                  setAiSuggestions(result.suggestions);
                } catch {
                  setShowSuggestions(false);
                  toast({ title: "تعذّر توليد الاقتراحات", description: "حاول مرة أخرى لاحقاً" });
                }
              }}
              disabled={suggestConversation.isPending}
              className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg text-sm font-medium transition-all"
              style={{
                background: suggestConversation.isPending
                  ? "hsl(220 28% 12%)"
                  : "linear-gradient(135deg, hsl(187 100% 42% / 0.2), hsl(270 60% 50% / 0.15))",
                borderWidth: 1,
                borderStyle: "solid",
                borderColor: "hsl(187 100% 42% / 0.4)",
                color: "hsl(187 100% 72%)",
              }}
            >
              {suggestConversation.isPending ? (
                <>
                  <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" strokeOpacity="0.3" />
                    <path d="M12 2a10 10 0 0 1 10 10" />
                  </svg>
                  يفكر الذكاء الاصطناعي...
                </>
              ) : (
                <>
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" style={{ color: "hsl(270 80% 70%)" }}>
                    <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6z" />
                  </svg>
                  اقتراحات للمحادثة بالذكاء الاصطناعي
                </>
              )}
            </button>

            {/* AI suggestions display */}
            {showSuggestions && aiSuggestions.length > 0 && (
              <div className="space-y-2 fade-in-up">
                <p className="text-xs text-muted-foreground text-right">اختر جملة لبدء المحادثة:</p>
                {aiSuggestions.map((s, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      navigator.clipboard?.writeText(s).catch(() => {});
                      toast({ title: "تم النسخ ✓", description: s });
                    }}
                    className="w-full text-right text-sm px-3 py-2.5 rounded-lg transition-all hover:scale-[1.01] active:scale-[0.99]"
                    style={{
                      backgroundColor: "hsl(220 28% 13%)",
                      borderWidth: 1,
                      borderStyle: "solid",
                      borderColor: "hsl(270 60% 50% / 0.3)",
                      color: "hsl(210 30% 88%)",
                      lineHeight: "1.6",
                    }}
                  >
                    <span style={{ color: "hsl(270 80% 70%)", marginLeft: "6px" }}>{i + 1}.</span>
                    {s}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Radar legend */}
        {!isPaused && (
          <div className="flex items-center gap-4 text-xs text-muted-foreground justify-center">
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full inline-block" style={{ border: "2px solid hsl(142 71% 45%)", boxShadow: "0 0 6px rgba(0,200,120,0.6)" }} />
              اهتمامات مشتركة
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full inline-block" style={{ border: "2px solid hsl(187 100% 60%)" }} />
              متصل الآن
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-3 h-3 rounded-full inline-block" style={{ border: "2px solid hsl(187 100% 42%)" }} />
              قريب منك
            </span>
          </div>
        )}

        {/* Nearby users list */}
        {!isPaused && nearbyUsers.length > 0 && (
          <div>
            <h2 className="text-sm font-semibold text-muted-foreground mb-3">
              الأشخاص القريبون ({nearbyUsers.length})
            </h2>
            <div className="space-y-2">
              {nearbyUsers.map((u) => {
                const common = (u.interests ?? []).filter((i) => myInterests.has(i));
                return (
                  <div
                    key={u.id}
                    className="rounded-xl border p-3 cursor-pointer transition-all hover:border-primary/40"
                    style={{
                      backgroundColor: "hsl(220 28% 9%)",
                      borderColor: common.length > 0 ? "hsl(142 71% 45% / 0.4)" : "hsl(210 25% 18%)",
                    }}
                    onClick={() => navigate(`/profile/${u.id}`)}
                  >
                    <UserCard user={u} showDistance />
                    {common.length > 0 && (
                      <div className="flex flex-wrap gap-1.5 mt-2 pt-2" style={{ borderTop: "1px solid hsl(210 25% 16%)" }}>
                        <span className="text-xs font-medium" style={{ color: "hsl(142 71% 45%)" }}>
                          اهتمام مشترك:
                        </span>
                        {common.map((tag) => (
                          <span
                            key={tag}
                            className="text-xs px-2 py-0.5 rounded-full"
                            style={{ backgroundColor: "hsl(142 71% 45% / 0.15)", color: "hsl(142 71% 65%)", border: "1px solid hsl(142 71% 45% / 0.3)" }}
                          >
                            {tag}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

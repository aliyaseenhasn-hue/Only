import { useState } from "react";
import { useLocation } from "wouter";
import { useGetAllUsers } from "@workspace/api-client-react";
import { getCurrentUser } from "@/lib/currentUser";
import NavBar from "@/components/NavBar";

const DEFAULT_LAT = 24.7136;
const DEFAULT_LNG = 46.6753;

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

const INTEREST_COLORS = [
  "hsl(187 100% 42%)", "hsl(267 83% 60%)", "hsl(142 71% 45%)",
  "hsl(43 96% 56%)", "hsl(0 72% 51%)", "hsl(210 80% 60%)",
];

export default function DiscoverPage() {
  const [, navigate] = useLocation();
  const currentUser = getCurrentUser();
  const [filter, setFilter] = useState("");

  const { data: allUsers = [], isLoading } = useGetAllUsers();

  const lat = DEFAULT_LAT;
  const lng = DEFAULT_LNG;

  const filtered = allUsers
    .filter((u) => u.id !== currentUser?.id)
    .filter((u) =>
      !filter ||
      u.name.includes(filter) ||
      (u.interests ?? []).some((i) => i.includes(filter))
    )
    .map((u) => ({
      ...u,
      distanceKm:
        u.lat != null && u.lng != null
          ? haversineKm(lat, lng, u.lat, u.lng)
          : null,
    }))
    .sort((a, b) => (a.distanceKm ?? 999) - (b.distanceKm ?? 999));

  return (
    <div className="min-h-screen bg-background grid-bg" dir="rtl">
      <NavBar />

      <div className="max-w-2xl mx-auto px-4 py-6 space-y-5">
        {/* Header */}
        <div>
          <h1 className="text-xl font-bold" style={{ color: "hsl(187 100% 42%)" }}>
            اكتشف الأشخاص
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            {allUsers.length} شخص مسجّل في التطبيق
          </p>
        </div>

        {/* Search */}
        <input
          type="search"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          placeholder="ابحث بالاسم أو الاهتمام..."
          className="w-full px-4 py-2.5 rounded-lg bg-card border text-foreground placeholder:text-muted-foreground focus:outline-none"
          style={{ borderColor: "hsl(210 25% 20%)" }}
        />

        {isLoading && (
          <div className="text-center py-12 text-muted-foreground">جاري التحميل...</div>
        )}

        {/* Grid */}
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {filtered.map((u, i) => (
            <button
              key={u.id}
              onClick={() => navigate(`/profile/${u.id}`)}
              className="rounded-xl border p-4 text-right transition-all hover:border-primary/40 fade-in-up"
              style={{
                backgroundColor: "hsl(220 28% 9%)",
                borderColor: "hsl(210 25% 18%)",
                animationDelay: `${i * 0.05}s`,
              }}
            >
              <div className="flex items-start gap-3">
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  {u.avatarUrl ? (
                    <img
                      src={u.avatarUrl}
                      alt={u.name}
                      className="w-12 h-12 rounded-full border-2"
                      style={{ borderColor: u.isOnline ? "hsl(142 71% 45%)" : "hsl(210 25% 20%)" }}
                    />
                  ) : (
                    <div
                      className="w-12 h-12 rounded-full border-2 flex items-center justify-center text-lg font-bold"
                      style={{
                        backgroundColor: "hsl(187 100% 42% / 0.2)",
                        borderColor: "hsl(187 100% 42%)",
                        color: "hsl(187 100% 42%)",
                      }}
                    >
                      {u.name[0]}
                    </div>
                  )}
                  {u.isOnline && (
                    <div
                      className="absolute -bottom-0.5 -left-0.5 w-3.5 h-3.5 rounded-full border-2 online-pulse"
                      style={{ backgroundColor: "hsl(142 71% 45%)", borderColor: "hsl(220 28% 9%)" }}
                    />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold truncate text-foreground">{u.name}</span>
                    {u.distanceKm != null && (
                      <span className="text-xs flex-shrink-0" style={{ color: "hsl(187 100% 42%)" }}>
                        {u.distanceKm.toFixed(1)} كم
                      </span>
                    )}
                  </div>

                  {u.bio && (
                    <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{u.bio}</p>
                  )}

                  {(u.interests ?? []).length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {(u.interests ?? []).slice(0, 3).map((interest, idx) => (
                        <span
                          key={interest}
                          className="px-2 py-0.5 rounded-full text-xs font-medium"
                          style={{
                            backgroundColor: `${INTEREST_COLORS[idx % INTEREST_COLORS.length]}18`,
                            color: INTEREST_COLORS[idx % INTEREST_COLORS.length],
                            border: `1px solid ${INTEREST_COLORS[idx % INTEREST_COLORS.length]}40`,
                          }}
                        >
                          {interest}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </button>
          ))}
        </div>

        {!isLoading && filtered.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            لا توجد نتائج
          </div>
        )}
      </div>
    </div>
  );
}

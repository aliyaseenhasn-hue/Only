import { useParams, useLocation } from "wouter";
import { useGetUser } from "@workspace/api-client-react";
import NavBar from "@/components/NavBar";

const INTEREST_COLORS = [
  "hsl(187 100% 42%)", "hsl(267 83% 60%)", "hsl(142 71% 45%)",
  "hsl(43 96% 56%)", "hsl(0 72% 51%)", "hsl(210 80% 60%)",
];

export default function ProfileView() {
  const params = useParams<{ userId: string }>();
  const [, navigate] = useLocation();
  const userId = Array.isArray(params.userId) ? params.userId[0] : params.userId;

  const { data: user, isLoading, isError } = useGetUser(userId, {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    query: { enabled: !!userId } as any,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background grid-bg" dir="rtl">
        <NavBar />
        <div className="flex items-center justify-center h-64 text-muted-foreground">
          جاري التحميل...
        </div>
      </div>
    );
  }

  if (isError || !user) {
    return (
      <div className="min-h-screen bg-background grid-bg" dir="rtl">
        <NavBar />
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <p className="text-muted-foreground">لم يتم العثور على الملف الشخصي</p>
          <button
            onClick={() => navigate("/")}
            className="px-4 py-2 rounded-lg text-sm font-medium"
            style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
          >
            العودة للرادار
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background grid-bg" dir="rtl">
      <NavBar />
      <div className="max-w-lg mx-auto px-4 py-8">
        {/* Profile card */}
        <div
          className="rounded-2xl border p-6 fade-in-up glow-cyan"
          style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(187 100% 42% / 0.3)" }}
        >
          {/* Avatar */}
          <div className="flex flex-col items-center gap-4 mb-6">
            <div className="relative">
              {user.avatarUrl ? (
                <img
                  src={user.avatarUrl}
                  alt={user.name}
                  className="w-24 h-24 rounded-full border-4"
                  style={{ borderColor: user.isOnline ? "hsl(142 71% 45%)" : "hsl(187 100% 42%)" }}
                />
              ) : (
                <div
                  className="w-24 h-24 rounded-full border-4 flex items-center justify-center text-3xl font-bold"
                  style={{
                    backgroundColor: "hsl(187 100% 42% / 0.15)",
                    borderColor: "hsl(187 100% 42%)",
                    color: "hsl(187 100% 42%)",
                  }}
                >
                  {user.name[0]}
                </div>
              )}
              {user.isOnline && (
                <div
                  className="absolute bottom-0 left-0 w-5 h-5 rounded-full border-2 online-pulse"
                  style={{ backgroundColor: "hsl(142 71% 45%)", borderColor: "hsl(220 28% 9%)" }}
                />
              )}
            </div>

            <div className="text-center">
              <h1 className="text-2xl font-bold text-foreground">{user.name}</h1>
              <p className="text-sm mt-1" style={{ color: user.isOnline ? "hsl(142 71% 45%)" : "hsl(210 20% 55%)" }}>
                {user.isOnline ? "متصل الآن" : "غير متصل"}
              </p>
            </div>
          </div>

          {/* Bio */}
          {user.bio && (
            <div className="mb-5">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-2">
                نبذة
              </h2>
              <p className="text-foreground text-sm leading-relaxed">{user.bio}</p>
            </div>
          )}

          {/* Interests */}
          {(user.interests ?? []).length > 0 && (
            <div className="mb-5">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                الاهتمامات
              </h2>
              <div className="flex flex-wrap gap-2">
                {(user.interests ?? []).map((interest, i) => (
                  <span
                    key={interest}
                    className="px-3 py-1.5 rounded-full text-sm font-medium"
                    style={{
                      backgroundColor: `${INTEREST_COLORS[i % INTEREST_COLORS.length]}15`,
                      color: INTEREST_COLORS[i % INTEREST_COLORS.length],
                      border: `1px solid ${INTEREST_COLORS[i % INTEREST_COLORS.length]}40`,
                    }}
                  >
                    {interest}
                  </span>
                ))}
              </div>
            </div>
          )}

          {/* Instagram */}
          {user.instagramHandle && (
            <div className="mb-6">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">
                إنستقرام
              </h2>
              <a
                href={`https://instagram.com/${user.instagramHandle}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all group"
                style={{
                  background: "linear-gradient(135deg, hsl(330 80% 25% / 0.3) 0%, hsl(280 60% 25% / 0.3) 50%, hsl(40 90% 30% / 0.3) 100%)",
                  border: "1px solid hsl(330 80% 45% / 0.4)",
                }}
              >
                {/* Instagram icon */}
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <linearGradient id="ig-grad" x1="0" y1="24" x2="24" y2="0">
                      <stop offset="0%" stopColor="#f09433" />
                      <stop offset="25%" stopColor="#e6683c" />
                      <stop offset="50%" stopColor="#dc2743" />
                      <stop offset="75%" stopColor="#cc2366" />
                      <stop offset="100%" stopColor="#bc1888" />
                    </linearGradient>
                  </defs>
                  <rect x="2" y="2" width="20" height="20" rx="5" ry="5" stroke="url(#ig-grad)" strokeWidth="2" fill="none" />
                  <circle cx="12" cy="12" r="4" stroke="url(#ig-grad)" strokeWidth="2" fill="none" />
                  <circle cx="17.5" cy="6.5" r="1.2" fill="url(#ig-grad)" />
                </svg>
                <span className="text-sm font-bold" style={{ color: "hsl(330 80% 75%)" }}>
                  @{user.instagramHandle}
                </span>
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" className="opacity-50 group-hover:opacity-100 transition-opacity" style={{ color: "hsl(330 80% 75%)" }}>
                  <path d="M7 17L17 7M17 7H7M17 7V17" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                </svg>
              </a>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            <button
              className="flex-1 py-3 rounded-xl font-bold text-sm transition-all glow-cyan"
              style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
              onClick={() => alert("تم الإشارة لـ " + user.name + "!")}
            >
              أشر إليه
            </button>
            <button
              className="flex-1 py-3 rounded-xl font-bold text-sm border transition-all"
              style={{
                backgroundColor: "transparent",
                borderColor: "hsl(187 100% 42% / 0.4)",
                color: "hsl(187 100% 42%)",
              }}
              onClick={() => navigate(-1 as never)}
            >
              رجوع
            </button>
          </div>
        </div>

        {/* Joined */}
        <p className="text-center text-xs text-muted-foreground mt-4">
          انضم في {new Date(user.createdAt).toLocaleDateString("ar-SA")}
        </p>
      </div>
    </div>
  );
}

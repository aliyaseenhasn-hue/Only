import { useLocation } from "wouter";

export default function LandingPage() {
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-background grid-bg flex flex-col" dir="rtl">
      {/* Nav */}
      <nav className="flex items-center justify-between px-6 py-4 border-b" style={{ borderColor: "hsl(210 25% 18%)" }}>
        <div className="flex items-center gap-2 font-bold text-lg" style={{ color: "hsl(187 100% 42%)" }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <circle cx="12" cy="12" r="3" fill="currentColor" />
            <circle cx="12" cy="12" r="7" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
            <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="1" opacity="0.3" />
          </svg>
          رادار اجتماعي
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => navigate("/sign-in/")}
            className="px-4 py-2 rounded-lg text-sm font-medium border transition-all"
            style={{ borderColor: "hsl(187 100% 42% / 0.4)", color: "hsl(187 100% 42%)" }}
          >
            تسجيل الدخول
          </button>
          <button
          onClick={() => navigate("/sign-up/")}
            className="px-4 py-2 rounded-lg text-sm font-medium transition-all glow-cyan"
            style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
          >
            ابدأ الآن
          </button>
        </div>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-16 text-center">
        {/* Animated radar icon */}
        <div className="relative mb-10">
          <div className="w-32 h-32 rounded-full border-2 flex items-center justify-center glow-cyan"
            style={{ borderColor: "hsl(187 100% 42% / 0.4)", backgroundColor: "hsl(220 28% 9%)" }}>
            <div className="w-24 h-24 rounded-full border flex items-center justify-center radar-pulse"
              style={{ borderColor: "hsl(187 100% 42% / 0.3)" }}>
              <svg width="40" height="40" viewBox="0 0 24 24" fill="none" style={{ color: "hsl(187 100% 42%)" }}>
                <circle cx="12" cy="12" r="3" fill="currentColor" />
                <circle cx="12" cy="12" r="7" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
                <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="1" opacity="0.3" />
              </svg>
            </div>
          </div>
          {/* Expanding ring */}
          <div className="absolute inset-0 rounded-full border radar-ring-expand"
            style={{ borderColor: "hsl(187 100% 42% / 0.3)" }} />
        </div>

        <h1 className="text-4xl font-black mb-4 glow-text-cyan" style={{ color: "hsl(187 100% 42%)" }}>
          اكتشف من حولك
        </h1>
        <p className="text-lg text-muted-foreground max-w-md mb-10 leading-relaxed">
          رادار اجتماعي ذكي يساعدك على العثور على الأشخاص القريبين منك الذين يشاركونك نفس الاهتمامات
        </p>

          <button
          onClick={() => navigate("/sign-up/")}
          className="px-8 py-3.5 rounded-xl font-bold text-base glow-cyan transition-transform hover:scale-105"
          style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
        >
          ابدأ الاستكشاف مجاناً
        </button>

        {/* Features */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-16 w-full max-w-2xl">
          {[
            { title: "رادار حي", desc: "شاشة رادار متحركة تعرض الأشخاص القريبين بشكل مرئي" },
            { title: "اهتمامات مشتركة", desc: "تصفية الأشخاص حسب الاهتمامات للعثور على أفضل التوافقات" },
            { title: "تنبيهات فورية", desc: "إشعار فوري عند وصول شخص قريب منك" },
          ].map((f) => (
            <div key={f.title} className="rounded-xl border p-4 text-right"
              style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(210 25% 18%)" }}>
              <h3 className="font-bold text-sm mb-1" style={{ color: "hsl(187 100% 42%)" }}>{f.title}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

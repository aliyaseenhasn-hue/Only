import { useState, useRef, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useCreateUser, useSendOtp, useVerifyOtp } from "@workspace/api-client-react";
import { setCurrentUser } from "@/lib/currentUser";

/* ── avatar helpers ── */
const AVATAR_SEEDS = [
  "sara","ahmed","noura","faisal","reem","omar","lamia","khalid",
  "mona","tariq","hind","bader",
];
const BG_COLORS = [
  "b6e3f4","c0aede","ffdfbf","d1f7c4","ffd3e8","e8d5b7",
  "c9f0ff","ffe4b5","f0d9ff","d4f0e8","ffecd2","e8f4fd",
];
const av = (seed: string, bg: string) =>
  `https://api.dicebear.com/7.x/avataaars/svg?seed=${seed}&backgroundColor=${bg}`;

/* ── phone formatter: keep only digits, max 10 ── */
const fmtPhone = (v: string) => v.replace(/\D/g, "").slice(0, 10);

/* ── full phone with country code ── */
function fullPhone(digits: string) {
  const d = digits.startsWith("0") ? digits.slice(1) : digits;
  return `+964${d}`;
}

/* ── masked phone for display ── */
function maskPhone(digits: string) {
  const d = digits.startsWith("0") ? digits : `0${digits}`;
  return `+964 ${d.slice(0, 4)} ${d.slice(4, 7)} ${"•".repeat(Math.max(0, d.length - 7))}`;
}

type Tab  = "signup" | "signin";
type Step = "form" | "otp";

/* ═══════════════════════════════════════════════
   OTP 4-box input
═══════════════════════════════════════════════ */
function OtpBoxes({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const refs = [
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
    useRef<HTMLInputElement>(null),
  ];

  function handleKey(i: number, e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Backspace" && !value[i] && i > 0) refs[i - 1].current?.focus();
  }

  function handleChange(i: number, e: React.ChangeEvent<HTMLInputElement>) {
    const ch = e.target.value.replace(/\D/g, "").slice(-1);
    const arr = value.padEnd(4, " ").split("");
    arr[i] = ch || " ";
    const next = arr.join("").trimEnd();
    onChange(next);
    if (ch && i < 3) setTimeout(() => refs[i + 1].current?.focus(), 0);
  }

  function handlePaste(e: React.ClipboardEvent) {
    const digits = e.clipboardData.getData("text").replace(/\D/g, "").slice(0, 4);
    if (digits) { onChange(digits); setTimeout(() => refs[Math.min(digits.length, 3)].current?.focus(), 0); }
    e.preventDefault();
  }

  return (
    <div className="flex gap-3 justify-center" dir="ltr">
      {[0, 1, 2, 3].map((i) => (
        <input
          key={i}
          ref={refs[i]}
          type="tel"
          inputMode="numeric"
          maxLength={1}
          value={value[i] && value[i] !== " " ? value[i] : ""}
          onChange={(e) => handleChange(i, e)}
          onKeyDown={(e) => handleKey(i, e)}
          onPaste={handlePaste}
          className="w-14 h-14 text-center text-2xl font-bold rounded-xl border-2 focus:outline-none transition-all"
          style={{
            background: "hsl(220 28% 11%)",
            borderColor: value[i] && value[i] !== " "
              ? "hsl(187 100% 42%)"
              : "hsl(210 25% 22%)",
            color: "hsl(187 100% 72%)",
            caretColor: "hsl(187 100% 42%)",
          }}
        />
      ))}
    </div>
  );
}

/* ═══════════════════════════════════════════════
   Countdown timer hook
═══════════════════════════════════════════════ */
function useCountdown(seconds: number) {
  const [left, setLeft] = useState(seconds);
  useEffect(() => {
    if (left <= 0) return;
    const id = setTimeout(() => setLeft((s) => s - 1), 1000);
    return () => clearTimeout(id);
  }, [left]);
  const reset = useCallback(() => setLeft(seconds), [seconds]);
  return { left, reset };
}

/* ═══════════════════════════════════════════════
   Phone field component
═══════════════════════════════════════════════ */
function PhoneField({ value, onChange }: { value: string; onChange: (v: string) => void }) {
  return (
    <div className="flex items-stretch rounded-xl overflow-hidden" style={{ border: "1px solid hsl(210 25% 22%)" }}>
      <div
        className="flex items-center gap-1.5 px-3 text-sm font-bold flex-shrink-0"
        style={{
          background: "hsl(220 28% 13%)",
          borderLeft: "1px solid hsl(210 25% 22%)",
          color: "hsl(187 100% 42%)",
        }}
      >
        <span className="text-base">🇮🇶</span>
        <span>+964</span>
      </div>
      <input
        type="tel"
        value={value}
        onChange={(e) => onChange(fmtPhone(e.target.value))}
        placeholder="07XX XXX XXXX"
        dir="ltr"
        maxLength={10}
        className="flex-1 px-3 py-2.5 text-foreground placeholder:text-muted-foreground focus:outline-none text-sm"
        style={{ background: "hsl(220 28% 11%)" }}
      />
    </div>
  );
}

/* ═══════════════════════════════════════════════
   Main page
═══════════════════════════════════════════════ */
export default function SignInPage() {
  const [, navigate] = useLocation();
  const [tab,  setTab]  = useState<Tab>("signup");
  const [step, setStep] = useState<Step>("form");

  /* form state */
  const [name,      setName]      = useState("");
  const [phone,     setPhone]     = useState("");
  const [instagram, setInstagram] = useState("");
  const [avatarIdx, setAvatarIdx] = useState(0);

  /* OTP state */
  const [otp,      setOtp]      = useState("");
  const [otpError, setOtpError] = useState("");
  const [devCode,  setDevCode]  = useState<string | null>(null);

  /* form errors */
  const [formError, setFormError] = useState("");

  const { left: countdown, reset: resetCountdown } = useCountdown(60);

  const createUser    = useCreateUser();
  const sendOtpMut    = useSendOtp();
  const verifyOtpMut  = useVerifyOtp();

  const selectedAvatar = av(AVATAR_SEEDS[avatarIdx], BG_COLORS[avatarIdx]);

  /* ── validate & send OTP ── */
  async function handleSendOtp() {
    setFormError("");
    if (tab === "signup" && !name.trim()) { setFormError("أدخل اسمك الكامل"); return; }
    const digits = phone.replace(/\D/g, "");
    if (digits.length < 10) { setFormError("أدخل رقم هاتف عراقي صحيح (10 أرقام)"); return; }

    try {
      const res = await sendOtpMut.mutateAsync({ data: { phone: fullPhone(digits) } });
      setDevCode(res.devCode ?? null);
      setOtp("");
      setOtpError("");
      resetCountdown();
      setStep("otp");
    } catch {
      setFormError("تعذّر إرسال الرمز، حاول مجدداً");
    }
  }

  /* ── resend ── */
  async function handleResend() {
    const digits = phone.replace(/\D/g, "");
    try {
      const res = await sendOtpMut.mutateAsync({ data: { phone: fullPhone(digits) } });
      setDevCode(res.devCode ?? null);
      setOtp("");
      setOtpError("");
      resetCountdown();
    } catch {
      setOtpError("تعذّر إعادة الإرسال");
    }
  }

  /* ── verify OTP then create/login ── */
  async function handleVerify() {
    if (otp.replace(/\s/g, "").length < 4) { setOtpError("أدخل الرمز المكوّن من 4 أرقام"); return; }
    setOtpError("");
    const digits = phone.replace(/\D/g, "");
    const fp = fullPhone(digits);

    try {
      await verifyOtpMut.mutateAsync({ data: { phone: fp, code: otp } });
    } catch (err: unknown) {
      const msg = (err as { response?: { data?: { error?: string } } })?.response?.data?.error
        ?? "رمز التحقق غير صحيح";
      setOtpError(msg);
      return;
    }

    /* OTP verified — create user */
    try {
      const user = await createUser.mutateAsync({
        data: {
          name: tab === "signup" ? name.trim() : `مستخدم ${digits.slice(-4)}`,
          avatarUrl: tab === "signup" ? selectedAvatar : av(AVATAR_SEEDS[0], BG_COLORS[0]),
          interests: [],
          instagramHandle: tab === "signup" ? instagram.trim() || undefined : undefined,
          phone: fp,
        },
      });
      setCurrentUser({
        id: user.id,
        name: user.name,
        avatarUrl: user.avatarUrl ?? undefined,
        interests: [],
        instagramHandle: tab === "signup" ? instagram.trim() || undefined : undefined,
        phone: fp,
      });
      navigate("/profile/setup");
    } catch {
      setOtpError("حدث خطأ أثناء إنشاء الحساب، حاول مجدداً");
    }
  }

  const isWorking = sendOtpMut.isPending || verifyOtpMut.isPending || createUser.isPending;

  /* ── auto-verify when 4 digits entered ── */
  useEffect(() => {
    if (otp.replace(/\s/g, "").length === 4 && step === "otp") {
      handleVerify();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [otp]);

  return (
    <div className="min-h-screen bg-background grid-bg flex items-center justify-center px-4 py-8" dir="rtl">
      <div className="w-full max-w-sm">

        {/* Logo */}
        <div className="text-center mb-7">
          <div
            className="inline-flex items-center justify-center w-14 h-14 rounded-full mb-3"
            style={{ background: "hsl(187 100% 42% / 0.12)", border: "1.5px solid hsl(187 100% 42% / 0.5)" }}
          >
            <svg width="26" height="26" viewBox="0 0 24 24" fill="none" style={{ color: "hsl(187 100% 42%)" }}>
              <circle cx="12" cy="12" r="3" fill="currentColor" />
              <circle cx="12" cy="12" r="7" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
              <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="1" opacity="0.3" />
              <line x1="12" y1="12" x2="19" y2="5" stroke="currentColor" strokeWidth="1.5" opacity="0.9" strokeLinecap="round" />
            </svg>
          </div>
          <h1 className="text-2xl font-extrabold" style={{ color: "hsl(187 100% 42%)" }}>سوشيال رادار</h1>
          <p className="text-muted-foreground text-sm mt-0.5">اكتشف الأشخاص القريبين منك</p>
        </div>

        {/* ══════════════ OTP STEP ══════════════ */}
        {step === "otp" ? (
          <div
            className="rounded-2xl p-6 space-y-5 fade-in-up"
            style={{ background: "hsl(220 28% 9%)", border: "1px solid hsl(210 25% 18%)" }}
          >
            {/* Header */}
            <div className="text-center space-y-1">
              <div
                className="inline-flex items-center justify-center w-12 h-12 rounded-full mb-2"
                style={{ background: "hsl(187 100% 42% / 0.12)", border: "1px solid hsl(187 100% 42% / 0.4)" }}
              >
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="hsl(187 100% 42%)" strokeWidth="2" strokeLinecap="round">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.12 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
              </div>
              <h2 className="text-lg font-bold text-foreground">تحقق من رقمك</h2>
              <p className="text-sm text-muted-foreground">
                أرسلنا رمز تحقق إلى
              </p>
              <p className="text-sm font-bold" style={{ color: "hsl(187 100% 62%)", direction: "ltr" }}>
                {maskPhone(phone)}
              </p>
            </div>

            {/* Dev code banner */}
            {devCode && (
              <div
                className="rounded-xl px-4 py-3 text-center"
                style={{ background: "hsl(187 100% 42% / 0.08)", border: "1px dashed hsl(187 100% 42% / 0.5)" }}
              >
                <p className="text-xs text-muted-foreground mb-1">رمز التحقق التجريبي</p>
                <p className="text-3xl font-extrabold tracking-[0.3em]" style={{ color: "hsl(187 100% 52%)" }}>
                  {devCode}
                </p>
                <p className="text-xs text-muted-foreground mt-1">(يظهر هذا فقط في وضع التطوير)</p>
              </div>
            )}

            {/* OTP boxes */}
            <OtpBoxes value={otp} onChange={setOtp} />

            {/* Error */}
            {otpError && (
              <p className="text-red-400 text-sm text-center">{otpError}</p>
            )}

            {/* Verify button */}
            <button
              type="button"
              onClick={handleVerify}
              disabled={isWorking || otp.replace(/\s/g, "").length < 4}
              className="w-full py-2.5 rounded-xl font-bold text-sm transition-all"
              style={{
                background: "hsl(187 100% 42%)",
                color: "hsl(220 30% 5%)",
                opacity: (isWorking || otp.replace(/\s/g, "").length < 4) ? 0.5 : 1,
              }}
            >
              {isWorking ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" strokeOpacity="0.3" />
                    <path d="M12 2a10 10 0 0 1 10 10" />
                  </svg>
                  جاري التحقق...
                </span>
              ) : "تأكيد الرمز"}
            </button>

            {/* Resend + back */}
            <div className="flex items-center justify-between text-sm">
              <button
                type="button"
                onClick={() => { setStep("form"); setOtp(""); setOtpError(""); }}
                className="text-muted-foreground hover:text-foreground transition-colors"
              >
                ← تغيير الرقم
              </button>
              {countdown > 0 ? (
                <span className="text-muted-foreground">
                  إعادة إرسال ({countdown}s)
                </span>
              ) : (
                <button
                  type="button"
                  onClick={handleResend}
                  disabled={sendOtpMut.isPending}
                  style={{ color: "hsl(187 100% 42%)" }}
                  className="font-bold"
                >
                  إعادة إرسال الرمز
                </button>
              )}
            </div>
          </div>

        ) : (
        /* ══════════════ FORM STEP ══════════════ */
        <>
          {/* Tabs */}
          <div
            className="flex rounded-xl p-1 mb-4"
            style={{ background: "hsl(220 28% 9%)", border: "1px solid hsl(210 25% 18%)" }}
          >
            {([["signup", "تسجيل جديد"], ["signin", "دخول"]] as [Tab, string][]).map(([t, label]) => (
              <button
                key={t}
                onClick={() => { setTab(t); setFormError(""); }}
                className="flex-1 py-2 rounded-lg text-sm font-bold transition-all"
                style={tab === t
                  ? { background: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }
                  : { background: "transparent", color: "hsl(210 20% 55%)" }}
              >
                {label}
              </button>
            ))}
          </div>

          <div
            className="rounded-2xl p-5 space-y-4"
            style={{ background: "hsl(220 28% 9%)", border: "1px solid hsl(210 25% 18%)" }}
          >
            {/* Google button */}
            <button
              type="button"
              onClick={() => alert("سيكون متاحاً في الإصدار الرسمي مع تسجيل الدخول عبر Google")}
              className="w-full flex items-center justify-center gap-3 py-2.5 rounded-xl text-sm font-bold transition-all hover:opacity-80"
              style={{ background: "hsl(220 28% 13%)", border: "1px solid hsl(210 25% 22%)", color: "hsl(210 30% 85%)" }}
            >
              <svg width="18" height="18" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.2 0 5.9 1.1 8.1 2.9l6-6C34.5 3.1 29.6 1 24 1 15.3 1 7.9 6 4.2 13.3l7 5.4C13 13.2 18.1 9.5 24 9.5z" />
                <path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v8.5h12.7c-.6 3-2.3 5.5-4.8 7.2l7.4 5.7c4.3-4 6.8-9.9 6.8-16.9z" />
                <path fill="#FBBC05" d="M11.2 28.7A14.6 14.6 0 0 1 9.5 24c0-1.6.3-3.2.7-4.7l-7-5.4A23.9 23.9 0 0 0 0 24c0 3.9.9 7.5 2.6 10.8l8.6-6.1z" />
                <path fill="#34A853" d="M24 47c5.6 0 10.3-1.8 13.7-5l-7.4-5.7c-1.8 1.2-4.1 1.9-6.3 1.9-5.9 0-10.9-3.8-12.7-9L3.3 35.1C7.1 42.4 15 47 24 47z" />
              </svg>
              {tab === "signup" ? "إنشاء حساب بواسطة Google" : "تسجيل الدخول بواسطة Google"}
            </button>

            {/* Divider */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-px" style={{ background: "hsl(210 25% 20%)" }} />
              <span className="text-xs text-muted-foreground">أو بالهاتف</span>
              <div className="flex-1 h-px" style={{ background: "hsl(210 25% 20%)" }} />
            </div>

            {/* ── SIGN UP fields ── */}
            {tab === "signup" && (
              <>
                {/* Avatar */}
                <div className="flex flex-col items-center gap-2">
                  <p className="text-xs text-muted-foreground">اختر صورتك الشخصية</p>
                  <img
                    src={selectedAvatar}
                    alt="avatar"
                    className="w-16 h-16 rounded-full border-2"
                    style={{ borderColor: "hsl(187 100% 42%)" }}
                  />
                  <div className="flex gap-1.5 flex-wrap justify-center">
                    {AVATAR_SEEDS.map((seed, i) => (
                      <button
                        key={seed}
                        type="button"
                        onClick={() => setAvatarIdx(i)}
                        className="w-8 h-8 rounded-full overflow-hidden border-2 transition-all"
                        style={{
                          borderColor: avatarIdx === i ? "hsl(187 100% 42%)" : "transparent",
                          opacity: avatarIdx === i ? 1 : 0.45,
                          transform: avatarIdx === i ? "scale(1.1)" : "scale(1)",
                        }}
                      >
                        <img src={av(seed, BG_COLORS[i])} alt="" className="w-full h-full" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                    الاسم الكامل <span style={{ color: "hsl(187 100% 42%)" }}>*</span>
                  </label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: أحمد علي"
                    className="w-full px-3 py-2.5 rounded-xl border text-foreground placeholder:text-muted-foreground focus:outline-none text-sm transition-all"
                    style={{ background: "hsl(220 28% 11%)", borderColor: "hsl(210 25% 22%)" }}
                  />
                </div>
              </>
            )}

            {/* Phone */}
            <div>
              <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                رقم الهاتف العراقي <span style={{ color: "hsl(187 100% 42%)" }}>*</span>
              </label>
              <PhoneField value={phone} onChange={setPhone} />
            </div>

            {/* Instagram (sign-up only) */}
            {tab === "signup" && (
              <div>
                <label className="block text-xs font-medium text-muted-foreground mb-1.5">
                  حساب الإنستقرام
                </label>
                <div
                  className="flex items-stretch rounded-xl overflow-hidden"
                  style={{ border: "1px solid hsl(210 25% 22%)" }}
                >
                  <div
                    className="flex items-center px-3 flex-shrink-0"
                    style={{ background: "hsl(220 28% 13%)", borderLeft: "1px solid hsl(210 25% 22%)" }}
                  >
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <defs>
                        <linearGradient id="ig-f" x1="0" y1="24" x2="24" y2="0">
                          <stop offset="0%" stopColor="#f09433" />
                          <stop offset="50%" stopColor="#dc2743" />
                          <stop offset="100%" stopColor="#bc1888" />
                        </linearGradient>
                      </defs>
                      <rect x="2" y="2" width="20" height="20" rx="5" stroke="url(#ig-f)" strokeWidth="2" fill="none" />
                      <circle cx="12" cy="12" r="4" stroke="url(#ig-f)" strokeWidth="2" fill="none" />
                      <circle cx="17.5" cy="6.5" r="1.2" fill="url(#ig-f)" />
                    </svg>
                  </div>
                  <span
                    className="flex items-center px-2 text-sm font-bold select-none"
                    style={{ background: "hsl(220 28% 11%)", color: "hsl(210 20% 45%)" }}
                  >@</span>
                  <input
                    type="text"
                    value={instagram}
                    onChange={(e) => setInstagram(e.target.value.replace(/^@/, ""))}
                    placeholder="username"
                    dir="ltr"
                    className="flex-1 pl-1 pr-3 py-2.5 text-foreground placeholder:text-muted-foreground focus:outline-none text-sm"
                    style={{ background: "hsl(220 28% 11%)" }}
                  />
                </div>
              </div>
            )}

            {formError && <p className="text-red-400 text-xs text-center">{formError}</p>}

            {/* Send OTP button */}
            <button
              type="button"
              onClick={handleSendOtp}
              disabled={isWorking}
              className="w-full py-2.5 rounded-xl font-bold text-sm transition-all"
              style={{
                background: "hsl(187 100% 42%)",
                color: "hsl(220 30% 5%)",
                opacity: isWorking ? 0.7 : 1,
              }}
            >
              {sendOtpMut.isPending ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="10" strokeOpacity="0.3" />
                    <path d="M12 2a10 10 0 0 1 10 10" />
                  </svg>
                  جاري الإرسال...
                </span>
              ) : "إرسال رمز التحقق"}
            </button>
          </div>

          <p className="text-center text-xs text-muted-foreground mt-4" style={{ lineHeight: "1.6" }}>
            بالتسجيل، أنت توافق على شروط الاستخدام وسياسة الخصوصية
          </p>
        </>
        )}
      </div>
    </div>
  );
}

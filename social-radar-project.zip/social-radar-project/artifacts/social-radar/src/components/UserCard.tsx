import { useLocation } from "wouter";

const INTEREST_COLORS = [
  "hsl(187 100% 42%)", "hsl(267 83% 60%)", "hsl(142 71% 45%)",
  "hsl(43 96% 56%)", "hsl(0 72% 51%)", "hsl(210 80% 60%)",
];

interface User {
  id: string;
  name: string;
  bio?: string | null;
  avatarUrl?: string | null;
  interests?: string[] | null;
  isOnline: boolean;
  distanceKm?: number;
}

interface Props {
  user: User;
  showDistance?: boolean;
}

export default function UserCard({ user, showDistance }: Props) {
  const [, navigate] = useLocation();

  return (
    <div className="flex items-start gap-3">
      {/* Avatar */}
      <div className="relative flex-shrink-0">
        {user.avatarUrl ? (
          <img
            src={user.avatarUrl}
            alt={user.name}
            className="w-11 h-11 rounded-full border-2"
            style={{ borderColor: user.isOnline ? "hsl(142 71% 45%)" : "hsl(210 25% 20%)" }}
          />
        ) : (
          <div
            className="w-11 h-11 rounded-full border-2 flex items-center justify-center font-bold"
            style={{
              backgroundColor: "hsl(187 100% 42% / 0.15)",
              borderColor: "hsl(187 100% 42%)",
              color: "hsl(187 100% 42%)",
            }}
          >
            {user.name[0]}
          </div>
        )}
        {user.isOnline && (
          <div
            className="absolute -bottom-0.5 -left-0.5 w-3 h-3 rounded-full border-2 online-pulse"
            style={{
              backgroundColor: "hsl(142 71% 45%)",
              borderColor: "hsl(220 28% 9%)",
            }}
          />
        )}
      </div>

      {/* Info */}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className="font-semibold text-sm text-foreground truncate">{user.name}</span>
          {showDistance && user.distanceKm != null && (
            <span className="text-xs flex-shrink-0 mr-2" style={{ color: "hsl(187 100% 42%)" }}>
              {user.distanceKm.toFixed(1)} كم
            </span>
          )}
        </div>

        {user.bio && (
          <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{user.bio}</p>
        )}

        {(user.interests ?? []).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1.5">
            {(user.interests ?? []).slice(0, 4).map((interest, i) => (
              <span
                key={interest}
                className="px-2 py-0.5 rounded-full text-xs"
                style={{
                  backgroundColor: `${INTEREST_COLORS[i % INTEREST_COLORS.length]}12`,
                  color: INTEREST_COLORS[i % INTEREST_COLORS.length],
                  border: `1px solid ${INTEREST_COLORS[i % INTEREST_COLORS.length]}35`,
                }}
              >
                {interest}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

import { useLocation } from "wouter";
import { getCurrentUser } from "@/lib/currentUser";
import { useClerkContext } from "@/lib/clerkContext";

export default function NavBar() {
  const [location, navigate] = useLocation();
  const { available: clerkAvailable, signOut, clerkUserFirstName, clerkUserImageUrl } = useClerkContext();
  const currentUser = getCurrentUser();

  const displayName = clerkUserFirstName || currentUser?.name || "";
  const avatarUrl = currentUser?.avatarUrl || clerkUserImageUrl || undefined;

  const links = [
    { href: "/radar", label: "الرادار" },
    { href: "/discover", label: "اكتشف" },
  ];

  function handleSignOut() {
    if (signOut) {
      signOut({ redirectUrl: "/" });
    }
  }

  return (
    <nav
      className="border-b px-4 py-3 flex items-center justify-between sticky top-0 z-50"
      style={{
        backgroundColor: "hsl(220 30% 5% / 0.95)",
        borderColor: "hsl(210 25% 18%)",
        backdropFilter: "blur(12px)",
      }}
      dir="rtl"
    >
      {/* Logo */}
      <button
        onClick={() => navigate("/radar")}
        className="flex items-center gap-2 font-bold text-base"
        style={{ color: "hsl(187 100% 42%)" }}
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
          <circle cx="12" cy="12" r="3" fill="currentColor" />
          <circle cx="12" cy="12" r="7" stroke="currentColor" strokeWidth="1.5" opacity="0.6" />
          <circle cx="12" cy="12" r="11" stroke="currentColor" strokeWidth="1" opacity="0.3" />
        </svg>
        رادار
      </button>

      {/* Links + user */}
      <div className="flex items-center gap-1">
        {links.map((link) => {
          const active = location === link.href;
          return (
            <button
              key={link.href}
              onClick={() => navigate(link.href)}
              className="px-3 py-1.5 rounded-lg text-sm font-medium transition-all"
              style={{
                backgroundColor: active ? "hsl(187 100% 42% / 0.12)" : "transparent",
                color: active ? "hsl(187 100% 42%)" : "hsl(210 20% 55%)",
                border: active ? "1px solid hsl(187 100% 42% / 0.3)" : "1px solid transparent",
              }}
            >
              {link.label}
            </button>
          );
        })}

        {/* User dropdown */}
        <div className="relative group mr-1">
          <button
            className="flex items-center gap-2 rounded-full border-2 overflow-hidden transition-transform hover:scale-105"
            style={{ borderColor: "hsl(187 100% 42% / 0.5)", padding: 0 }}
          >
            {avatarUrl ? (
              <img src={avatarUrl} alt={displayName} className="w-8 h-8 rounded-full" />
            ) : (
              <div
                className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold"
                style={{ backgroundColor: "hsl(187 100% 42%)", color: "hsl(220 30% 5%)" }}
              >
                {displayName[0] || "؟"}
              </div>
            )}
          </button>

          {/* Dropdown */}
          <div
            className="absolute left-0 top-full mt-2 w-44 rounded-xl border py-1 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all z-50"
            style={{ backgroundColor: "hsl(220 28% 9%)", borderColor: "hsl(210 25% 18%)" }}
          >
            {displayName && (
              <div className="px-3 py-2 border-b text-xs font-medium text-muted-foreground truncate"
                style={{ borderColor: "hsl(210 25% 18%)" }}>
                {displayName}
              </div>
            )}
            <button
              onClick={() => navigate("/profile/edit")}
              className="w-full text-right px-3 py-2 text-sm text-foreground hover:bg-accent/50 transition-colors"
            >
              تعديل الملف الشخصي
            </button>
            {currentUser && (
              <button
                onClick={() => navigate(`/profile/${currentUser.id}`)}
                className="w-full text-right px-3 py-2 text-sm text-foreground hover:bg-accent/50 transition-colors"
              >
                عرض ملفي
              </button>
            )}
            {clerkAvailable && (
              <>
                <div className="border-t my-1" style={{ borderColor: "hsl(210 25% 18%)" }} />
                <button
                  onClick={handleSignOut}
                  className="w-full text-right px-3 py-2 text-sm transition-colors"
                  style={{ color: "hsl(0 72% 51%)" }}
                >
                  تسجيل الخروج
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}

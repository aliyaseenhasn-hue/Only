const KEY = "social-radar-user";

export interface CurrentUser {
  id: string;
  name: string;
  bio?: string;
  avatarUrl?: string;
  interests: string[];
  instagramHandle?: string;
  phone?: string;
}

export function getCurrentUser(): CurrentUser | null {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function setCurrentUser(user: CurrentUser): void {
  localStorage.setItem(KEY, JSON.stringify(user));
}

export function clearCurrentUser(): void {
  localStorage.removeItem(KEY);
}

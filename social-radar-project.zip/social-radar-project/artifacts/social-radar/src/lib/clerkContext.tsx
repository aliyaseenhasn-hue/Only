import { createContext, useContext } from "react";
import type { ReactNode } from "react";

interface ClerkContextValue {
  available: boolean;
  signOut: ((opts?: { redirectUrl?: string }) => void) | null;
  clerkUserFirstName: string | null;
  clerkUserImageUrl: string | null;
}

const ClerkCtx = createContext<ClerkContextValue>({
  available: false,
  signOut: null,
  clerkUserFirstName: null,
  clerkUserImageUrl: null,
});

export function useClerkContext() {
  return useContext(ClerkCtx);
}

export function ClerkContextUnavailableProvider({ children }: { children: ReactNode }) {
  return (
    <ClerkCtx.Provider value={{ available: false, signOut: null, clerkUserFirstName: null, clerkUserImageUrl: null }}>
      {children}
    </ClerkCtx.Provider>
  );
}

export function ClerkContextAvailableProvider({ children }: { children: ReactNode }) {
  return <ClerkCtxFromHooks>{children}</ClerkCtxFromHooks>;
}

function ClerkCtxFromHooks({ children }: { children: ReactNode }) {
  const { useUser, useClerk } = require("@clerk/react") as typeof import("@clerk/react");
  const { user } = useUser();
  const { signOut } = useClerk();

  return (
    <ClerkCtx.Provider value={{
      available: true,
      signOut: (opts) => signOut({ redirectUrl: opts?.redirectUrl ?? "/" }),
      clerkUserFirstName: user?.firstName ?? null,
      clerkUserImageUrl: user?.imageUrl ?? null,
    }}>
      {children}
    </ClerkCtx.Provider>
  );
}

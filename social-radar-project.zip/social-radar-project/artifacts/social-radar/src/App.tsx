import { useEffect, useRef, Component } from "react";
import type { ReactNode } from "react";
import { Switch, Route, Router as WouterRouter, useLocation, Redirect } from "wouter";
import { QueryClient, QueryClientProvider, useQueryClient } from "@tanstack/react-query";
import { ClerkProvider, Show, SignIn, SignUp, useClerk } from "@clerk/react";
import { publishableKeyFromHost } from "@clerk/react/internal";
import { shadcn } from "@clerk/themes";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import RadarPage from "@/pages/RadarPage";
import ProfileSetup from "@/pages/ProfileSetup";
import ProfileView from "@/pages/ProfileView";
import ProfileEdit from "@/pages/ProfileEdit";
import DiscoverPage from "@/pages/DiscoverPage";
import LandingPage from "@/pages/LandingPage";
import DevSignInPage from "@/pages/SignInPage";
import NotFound from "@/pages/not-found";
import {
  ClerkContextUnavailableProvider,
  ClerkContextAvailableProvider,
} from "@/lib/clerkContext";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: 1, staleTime: 30_000 },
  },
});

const basePath = import.meta.env.BASE_URL.replace(/\/$/, "");

const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);

const clerkProxyUrl =
  import.meta.env.VITE_CLERK_PROXY_URL ||
  `${window.location.origin}/api/__clerk`;

function stripBase(path: string): string {
  return basePath && path.startsWith(basePath)
    ? path.slice(basePath.length) || "/"
    : path;
}

const clerkAppearance = {
  theme: shadcn,
  cssLayerName: "clerk",
  options: {
    logoPlacement: "inside" as const,
    logoLinkUrl: basePath || "/",
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
    socialButtonsPlacement: "top" as const,
    socialButtonsVariant: "blockButton" as const,
  },
  variables: {
    colorPrimary: "#00d4e8",
    colorForeground: "#d4f0f8",
    colorMutedForeground: "#6b8fa0",
    colorDanger: "#ef4444",
    colorBackground: "#0b1220",
    colorInput: "#111c2e",
    colorInputForeground: "#d4f0f8",
    colorNeutral: "#1e3048",
    fontFamily: "Tajawal, sans-serif",
    borderRadius: "0.75rem",
  },
  elements: {
    rootBox: "w-full flex justify-center",
    cardBox: "rounded-2xl w-[440px] max-w-full overflow-hidden",
    card: "!shadow-none !border-0 !bg-transparent !rounded-none",
    footer: "!shadow-none !border-0 !bg-transparent !rounded-none",
    headerTitle: "text-[#d4f0f8] font-bold",
    headerSubtitle: "text-[#6b8fa0]",
    socialButtonsBlockButtonText: "text-[#d4f0f8]",
    formFieldLabel: "text-[#d4f0f8]",
    footerActionLink: "text-[#00d4e8]",
    footerActionText: "text-[#6b8fa0]",
    dividerText: "text-[#6b8fa0]",
    identityPreviewEditButton: "text-[#00d4e8]",
    formFieldSuccessText: "text-[#4ade80]",
    alertText: "text-[#d4f0f8]",
    logoBox: "mb-2",
    logoImage: "h-10 w-10",
    socialButtonsBlockButton: "border border-[#1e3048] bg-[#111c2e] hover:bg-[#162235]",
    formButtonPrimary: "bg-[#00d4e8] text-[#0b1220] hover:bg-[#00bfcc] font-bold",
    formFieldInput: "bg-[#111c2e] border-[#1e3048] text-[#d4f0f8]",
    footerAction: "bg-transparent",
    dividerLine: "bg-[#1e3048]",
    alert: "bg-[#111c2e] border-[#1e3048]",
    otpCodeFieldInput: "bg-[#111c2e] border-[#1e3048] text-[#d4f0f8]",
    formFieldRow: "gap-2",
    main: "gap-4",
  },
};

function SignInPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 grid-bg">
      <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
    </div>
  );
}

function SignUpPage() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 grid-bg">
      <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
    </div>
  );
}

function HomeRedirect() {
  return (
    <>
      <Show when="signed-in">
        <Redirect to="/radar" />
      </Show>
      <Show when="signed-out">
        <LandingPage />
      </Show>
    </>
  );
}

function ProtectedRoute({ component: Component }: { component: React.ComponentType }) {
  return (
    <>
      <Show when="signed-in">
        <Component />
      </Show>
      <Show when="signed-out">
        <Redirect to="/" />
      </Show>
    </>
  );
}

function ClerkQueryClientCacheInvalidator() {
  const { addListener } = useClerk();
  const qc = useQueryClient();
  const prevUserIdRef = useRef<string | null | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = addListener(({ user }) => {
      const userId = user?.id ?? null;
      if (prevUserIdRef.current !== undefined && prevUserIdRef.current !== userId) {
        qc.clear();
      }
      prevUserIdRef.current = userId;
    });
    return unsubscribe;
  }, [addListener, qc]);

  return null;
}

function ClerkProviderWithRoutes() {
  const [, setLocation] = useLocation();

  return (
    <ClerkProvider
      publishableKey={clerkPubKey!}
      proxyUrl={clerkProxyUrl}
      appearance={clerkAppearance}
      signInUrl={`${basePath}/sign-in`}
      signUpUrl={`${basePath}/sign-up`}
      localization={{
        signIn: {
          start: {
            title: "مرحباً بعودتك",
            subtitle: "سجّل دخولك لاستكشاف من حولك",
          },
        },
        signUp: {
          start: {
            title: "انضم إلى الرادار",
            subtitle: "اكتشف الأشخاص القريبين منك",
          },
        },
      }}
      routerPush={(to) => setLocation(stripBase(to))}
      routerReplace={(to) => setLocation(stripBase(to), { replace: true })}
    >
      <ClerkContextAvailableProvider>
        <QueryClientProvider client={queryClient}>
          <TooltipProvider>
            <ClerkQueryClientCacheInvalidator />
            <Switch>
              <Route path="/" component={HomeRedirect} />
              <Route path="/sign-in/*?" component={SignInPage} />
              <Route path="/sign-up/*?" component={SignUpPage} />
              <Route path="/radar" component={() => <ProtectedRoute component={RadarPage} />} />
              <Route path="/profile/setup" component={() => <ProtectedRoute component={ProfileSetup} />} />
              <Route path="/profile/edit" component={() => <ProtectedRoute component={ProfileEdit} />} />
              <Route path="/profile/:userId" component={ProfileView} />
              <Route path="/discover" component={() => <ProtectedRoute component={DiscoverPage} />} />
              <Route component={NotFound} />
            </Switch>
            <Toaster />
          </TooltipProvider>
        </QueryClientProvider>
      </ClerkContextAvailableProvider>
    </ClerkProvider>
  );
}

function DevFallbackRoutes() {
  return (
    <ClerkContextUnavailableProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Switch>
            <Route path="/" component={LandingPage} />
            <Route path="/sign-in/*?" component={DevSignInPage} />
            <Route path="/sign-up/*?" component={DevSignInPage} />
            <Route path="/radar" component={RadarPage} />
            <Route path="/profile/setup" component={ProfileSetup} />
            <Route path="/profile/edit" component={ProfileEdit} />
            <Route path="/profile/:userId" component={ProfileView} />
            <Route path="/discover" component={DiscoverPage} />
            <Route component={NotFound} />
          </Switch>
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </ClerkContextUnavailableProvider>
  );
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ClerkErrorBoundary extends Component<{ children: ReactNode }, ErrorBoundaryState> {
  constructor(props: { children: ReactNode }) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  render() {
    if (this.state.hasError) {
      return <DevFallbackRoutes />;
    }
    return this.props.children;
  }
}

// Clerk test keys (pk_test_*) cannot use custom proxy hosts — they only work
// on clerk.localhost, which isn't accessible in Replit's container environment.
// Skip ClerkProvider in dev so the preview stays functional; production live
// keys (pk_live_*) support the proxy and Clerk activates automatically there.
const isLiveKey = clerkPubKey?.startsWith("pk_live_") ?? false;

function App() {
  return (
    <WouterRouter base={basePath}>
      {isLiveKey ? (
        <ClerkProviderWithRoutes />
      ) : (
        <DevFallbackRoutes />
      )}
    </WouterRouter>
  );
}

export default App;
